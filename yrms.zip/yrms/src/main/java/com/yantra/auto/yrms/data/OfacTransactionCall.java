package com.yantra.auto.yrms.data;

public class OfacTransactionCall {
	String transactionNumber;

	public String getTransactionNumber() {
		return transactionNumber;
	}

	public void setTransactionNumber(String transactionNumber) {
		this.transactionNumber = transactionNumber;
	}
}
