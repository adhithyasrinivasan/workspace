package com.yantra.auto.yrms.data;

public class Institution {
	private String institutionId;

	public String getInstitutionId() {
		return this.institutionId;
	}

	public void setInstitutionId(String institutionId) {
		this.institutionId = institutionId;
	}

	private String institutionName;

	public String getInstitutionName() {
		return this.institutionName;
	}

	public void setInstitutionName(String institutionName) {
		this.institutionName = institutionName;
	}
}