package com.yantra.auto.yrms.data;

public class Ofac
{
	private String ofacHit;

	public String getOfacHit() {
		return ofacHit;
	}

	public void setOfacHit(String ofacHit) {
		this.ofacHit = ofacHit;
	}
	
}