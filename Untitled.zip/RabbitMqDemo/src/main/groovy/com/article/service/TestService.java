package com.article.service;

import java.math.BigDecimal;

import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.article.dto.Article;

@Service
public class TestService {
	
	@Autowired
	RabbitTemplate template;
	
	public String testMethod(){
		
		template.convertAndSend("testQueue", "This is test");
		return "success";
	}
	
	/*public String testMethod(){
		
		Article article = new Article();
		article.setName("One Indian Girl");
		article.setAuthor("Chethan Bhagath");
		article.setPrice(new BigDecimal(450));
		article.setGst(new BigDecimal(10));
		articleRepository.save(article);
		return "Success";
	}*/

}
